<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_eri_nagy_traveler
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link href="https://fonts.googleapis.com/css?family=Arvo&display=swap" rel="stylesheet">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'cr12_eri_nagy_traveler' ); ?></a>

	<header id="masthead" class="site-header">
		<nav class="navbar navbar-expand-lg navbar-light bg-light main-navigation"  id="site-navigation" >
            <a class="navbar-brand" style="padding-bottom:0px; padding-top:0px;" href="#"><?php
			the_custom_logo();?></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarText">
               <?php
			wp_nav_menu( array(
				'theme_location' => 'menu-1',

				 'depth'             => 2, // 1 = no dropdowns, 2 = dropdown
				
				'menu_id'        => 'primary-menu',

				'container'         => 'div',
				
				'container_class'   => 'collapse navbar-collapse',

				'container_id'      => 'navbarText',

                'menu_class'        => 'nav navbar-nav',

				'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',

                'walker'            => new WP_Bootstrap_Navwalker()


			) );
			?>
			<span class="navbar-text"> <?php bloginfo('description'); ?> </span>
			<?php
			
			/*if ( is_front_page() && is_home() ) :
				?>
				<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<?php
			else :
				?>
				 <span class="navbar-text"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a> <span class="navbar-text">
				<?php
			endif;
			$cr12_eri_nagy_traveler_description = get_bloginfo( 'description', 'display' );
			if ( $cr12_eri_nagy_traveler_description || is_customize_preview() ) :
				?>
				 <span class="navbar-text"><?php echo $cr12_eri_nagy_traveler_description; /* WPCS: xss ok. */ ?><!--</span>-->
			<?php /*endif; */?>  
           
               S
            </div>
        </nav>
		
		
	</header><!-- #masthead -->
   
	<div id="content" class="site-content"  >
		<div class="sitetitle" style="height:300px; ">
			<h2 class="sitetitle"><?php bloginfo( 'name' ); ?></h2>
				<p class="sitedescription" >Enjoy our tour destination</p>
			</div>