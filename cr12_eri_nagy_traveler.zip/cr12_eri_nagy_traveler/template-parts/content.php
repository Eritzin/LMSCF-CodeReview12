<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cr12_eri_nagy_traveler
 */

?>

      <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
      			<?php 
		
          $image = wp_get_attachment_image_src(get_post_thumbnail_id());
         
		 ?>
      	<div class="card" style="width: 18rem;">
        
          <img src="<?php echo $image[0]; ?>" class="card-img-top"  />
           
         <div class="card-body">
		<?php
		if ( is_singular() ) :
			the_title( ' <h5 class="card-title">', '</h5>' );
		else :
			the_title( '<h5 class="card-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h5>' );
		endif;?>
		<p class="card-text">
		<?php
		$text = get_the_excerpt();
		$short=wp_trim_words( $text, 20, '...' );
		echo $short;
		
        
		wp_link_pages( array(
			'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'cr12_eri_nagy_traveler' ),
			'after'  => '</div>',
		) );
		?>
	     </p><!-- .entry-content -->
	     <?php
		if ( 'post' === get_post_type() ) :
			?>
			<p class="card-text"><small class="text-muted">
				<?php
				cr12_eri_nagy_traveler_posted_on();
				cr12_eri_nagy_traveler_posted_by();
				?>
			</small></p><!-- .entry-meta -->
		<?php endif; ?>
	
	

	

	<footer class="entry-footer">
		<?php cr12_eri_nagy_traveler_entry_footer(); ?>
	</footer><!-- .entry-footer -->
</div>
</article><!-- #post-<?php the_ID(); ?> -->
